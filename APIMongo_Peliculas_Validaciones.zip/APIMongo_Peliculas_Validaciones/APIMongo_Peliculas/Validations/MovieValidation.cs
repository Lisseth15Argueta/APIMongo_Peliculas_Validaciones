﻿using APIMongo_Peliculas.Models;
using FluentValidation;

namespace APIMongo_Peliculas.Validations
{
	public class MovieValidation : AbstractValidator<Movie>
	{
        public MovieValidation()
        {
            RuleFor(movie => movie.MovieName)
                .NotEmpty()
                .WithMessage("El Nombre de la pelicula es Obligatorio")
                .Length(3, 100).WithMessage("El nombre debe tener al menos 3 caracteres");

			RuleFor(movie => movie.Duration)
				.NotEmpty()
				.WithMessage("La duracion de la pelicula es Obligatorio")
				.Length(3, 100).WithMessage("La duracion debe tener al menos 3 caracteres");

			RuleFor(movie => movie.Category)
				.NotEmpty()
				.WithMessage("La categoria de la pelicula es Obligatorio")
				.Length(3, 100).WithMessage("La categoria debe tener al menos 3 caracteres");

			RuleFor(movie => movie.Author)
				.NotEmpty()
				.WithMessage("El Autor de la pelicula es Obligatorio")
				.Length(3, 100).WithMessage("El Autor debe tener al menos 3 caracteres");
		}
    }
}

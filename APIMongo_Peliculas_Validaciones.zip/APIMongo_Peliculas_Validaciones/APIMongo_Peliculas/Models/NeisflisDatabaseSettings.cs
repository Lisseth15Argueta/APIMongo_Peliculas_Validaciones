﻿namespace APIMongo_Peliculas.Models
{
	public class NeisflisDatabaseSettings
	{
		public string ConnectionString { get; set; } = null!;
		public string DatabaseName { get; set; } = null!;
		public string NeisflisCollectionName { get; set; } = null!;
	}
}
